package tema3_cajaNegra;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;

public class EquivalenciaEdadTest {
	
	@Test
	void siEsMayorEdad () {
		boolean resultado = Edad.esMayorDeEdad(20);
        assertEquals(resultado, true, "Error1: Es menor de edad.");
	}
	
	@Test
	void siEsMenorEdad () {
		boolean resultado = Edad.esMayorDeEdad(15);
        assertEquals(resultado, false, "Error2: Es mayor de edad.");
	}
}
