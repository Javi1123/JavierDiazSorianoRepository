package tema3_cajaNegra;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;


public class LimiteEdadTest {

	@Test
	void limiteMayor100 () {
		boolean resultado = Edad.esMayorDeEdad(100);
		assertEquals(resultado, false, "Edad limite mayor llegada (100).");
	}
	@Test
	void limiteMenor0 () {
		boolean resultado = Edad.esMayorDeEdad(0);
		assertEquals(resultado, false, "Edad limite menor llegada (0).");
	}
	@Test
	void limiteMayor101 () {
		boolean resultado = Edad.esMayorDeEdad(101);
		assertEquals(resultado, false, "Edad limite mayor superada (101).");
	}
	@Test
	void limiteMenor1 () {
		boolean resultado = Edad.esMayorDeEdad(-1);
		assertEquals(resultado, true, "Edad limite menor superada (-1).");
	}
}
